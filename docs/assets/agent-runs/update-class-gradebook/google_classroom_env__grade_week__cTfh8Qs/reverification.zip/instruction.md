Grade and return the requested "Week 1: Writing" work in the "Organize and Educate" course, then export and annotate the updated class gradebook.

For "Week 1: Writing", assess Casey Boehm's turned-in submission using the attached Writing Rubric for a total score of 7/8:  
- Sentence Writing: 2/2  
- Organization: 2/2  
- Punctuation: 2/2  
- Spelling: 1/2

Post the individual private comment "Awesome work sounding out your words and using sight words!" on that turned-in submission before returning work. Return three of the four "Week 1: Writing" roster records—both Casey Boehm entries (the turned-in submission and the unsubmitted entry) and Hannah Koenig's entry—with the shared private comment "Super sentence writing!" while leaving Caitie Instone's entry unreturned.

Once the "Week 1: Writing" grading and returns are complete, export all course grades for "Organize and Educate" into a complete class gradebook. Because this environment produces a local spreadsheet workbook rather than generating a live online spreadsheet, save the updated gradebook at `/home/ga/Documents/Grades Organize and Educate 08-06-2020.ods` and add the comment "Needs to make corrections" to cell D7 in that workbook.
