Public Harbor run results for premiere-pro_pi_20261124_220941_11271540

The job and trial metadata include the recorded usage, timing, and final result when available. agent/trajectory.json includes every recorded step, action type, numeric action arguments, and reported metrics. The Gym event index retains every recorded event. verifier/live-judge.json contains the final scores and reasons when a verdict exists. verifier/live-observations.jsonl contains the reviewed evidence for the verdicts, including tool calls and responses. The observation index includes all recorded verifier checks. Screenshots and collected deliverables are the public versions from the task page.

For public distribution, the export omits session credentials, host-specific locations, unreviewed free-text messages, tool payloads and screenshots, private setup and debug logs, and unpublished guest files. Some published screenshots are cropped. The original run folder is retained privately.
